import express from "express";
import cors from "cors";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("finance.db");
const JWT_SECRET = "waplay-secret-key-123";

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    password TEXT,
    reset_token TEXT,
    reset_token_expiry INTEGER,
    theme TEXT DEFAULT 'light',
    fixed_date TEXT
  );
  CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    description TEXT,
    amount REAL,
    type TEXT, -- 'income' or 'expense'
    category TEXT,
    date TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    name TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
  CREATE TABLE IF NOT EXISTS checklist_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    title TEXT,
    amount REAL DEFAULT 0,
    is_done INTEGER DEFAULT 0,
    month_year TEXT, -- 'yyyy-MM'
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Migration for existing users (adding email and reset columns if they don't exist)
try {
  db.exec("ALTER TABLE users ADD COLUMN email TEXT");
} catch (e) {}
try {
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email)");
} catch (e) {}
try {
  db.exec("ALTER TABLE users ADD COLUMN reset_token TEXT");
} catch (e) {}
try {
  db.exec("ALTER TABLE users ADD COLUMN reset_token_expiry INTEGER");
} catch (e) {}
try {
  db.exec("ALTER TABLE users ADD COLUMN theme TEXT DEFAULT 'light'");
} catch (e) {}
try {
  db.exec("ALTER TABLE users ADD COLUMN fixed_date TEXT");
} catch (e) {}
try {
  db.exec("ALTER TABLE checklist_items ADD COLUMN amount REAL DEFAULT 0");
} catch (e) {}

import nodemailer from "nodemailer";
import cryptoRandomString from "crypto-random-string";

async function startServer() {
  const app = express();
  
  // Enhanced CORS configuration
  app.use(cors({
    origin: '*', // Allow all origins for demo/easy deployment
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true
  }));
  
  app.use(express.json());
  
  console.log('[SERVER] Database initialized and CORS configured');

  app.get("/api/health", (req, res) => {
    console.log('[HEALTH] Check received');
    res.json({ 
      status: "ok", 
      time: new Date().toISOString(),
      env: process.env.NODE_ENV || 'development'
    });
  });

  // Email Transporter (Mock/Configurable)
  // In a real app, use process.env for these
  const transporter = nodemailer.createTransport({
    host: "smtp.ethereal.email",
    port: 587,
    secure: false,
    auth: {
      user: "mock-user@ethereal.email", // Replace with real credentials
      pass: "mock-pass",
    },
  });

  // Auth Routes
  app.post("/api/register", async (req, res) => {
    const { username, email, password } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const info = db.prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)").run(username, email, hashedPassword);
      res.json({ success: true, userId: info.lastInsertRowid });
    } catch (error) {
      res.status(400).json({ error: "Usuário ou e-mail já existe" });
    }
  });

  app.post("/api/forgot-password", async (req, res) => {
    const { email } = req.body;
    const user: any = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    
    if (!user) {
      return res.status(404).json({ error: "E-mail não encontrado" });
    }

    const token = cryptoRandomString({ length: 32, type: 'url-safe' });
    const expiry = Date.now() + 3600000; // 1 hour

    db.prepare("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?").run(token, expiry, user.id);

    // In a real app, the link would point to your frontend
    const resetLink = `${process.env.APP_URL || 'http://localhost:3000'}/reset-password?token=${token}`;

    console.log(`[RECOVERY] Link para ${email}: ${resetLink}`);

    // Simulate sending email
    // For demo purposes, we just return success and log the link
    // In production, uncomment the transporter.sendMail block
    /*
    await transporter.sendMail({
      from: '"Gestor Waplay" <noreply@waplay.com>',
      to: email,
      subject: "Recuperação de Conta",
      text: `Olá ${user.username}, use este link para resetar sua senha: ${resetLink}`,
      html: `<p>Olá <b>${user.username}</b>,</p><p>Use o link abaixo para resetar sua senha:</p><a href="${resetLink}">${resetLink}</a>`
    });
    */

    res.json({ success: true, message: "Link de recuperação enviado para o e-mail (verifique o console do servidor em ambiente de desenvolvimento)" });
  });

  app.post("/api/reset-password", async (req, res) => {
    const { token, newPassword } = req.body;
    const user: any = db.prepare("SELECT * FROM users WHERE reset_token = ? AND reset_token_expiry > ?").get(token, Date.now());

    if (!user) {
      return res.status(400).json({ error: "Token inválido ou expirado" });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    db.prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?").run(hashedPassword, user.id);

    res.json({ success: true, message: "Senha atualizada com sucesso" });
  });

  app.post("/api/login", async (req, res) => {
    const { username, password } = req.body;
    console.log(`[LOGIN] Attempt for username: ${username}`);
    try {
      const user: any = db.prepare("SELECT * FROM users WHERE username = ?").get(username);
      if (user && await bcrypt.compare(password, user.password)) {
        console.log(`[LOGIN] Success for user: ${username}`);
        const token = jwt.sign({ userId: user.id, username: user.username }, JWT_SECRET);
        res.json({ 
          token, 
          user: { 
            id: user.id, 
            username: user.username, 
            email: user.email,
            theme: user.theme,
            fixed_date: user.fixed_date
          } 
        });
      } else {
        console.log(`[LOGIN] Invalid credentials for: ${username}`);
        res.status(401).json({ error: "Credenciais inválidas" });
      }
    } catch (error) {
      console.error(`[LOGIN] Error:`, error);
      res.status(500).json({ error: "Erro interno no servidor" });
    }
  });

  // Transaction Routes
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.sendStatus(403);
      req.user = user;
      next();
    });
  };

  app.get("/api/transactions", authenticateToken, (req: any, res) => {
    const transactions = db.prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC").all(req.user.userId);
    res.json(transactions);
  });

  app.post("/api/transactions", authenticateToken, (req: any, res) => {
    const { description, amount, type, category, date } = req.body;
    const info = db.prepare(
      "INSERT INTO transactions (user_id, description, amount, type, category, date) VALUES (?, ?, ?, ?, ?, ?)"
    ).run(req.user.userId, description, amount, type, category, date);
    res.json({ id: info.lastInsertRowid });
  });

  app.put("/api/transactions/:id", authenticateToken, (req: any, res) => {
    const { description, amount, type, category, date } = req.body;
    db.prepare(
      "UPDATE transactions SET description = ?, amount = ?, type = ?, category = ?, date = ? WHERE id = ? AND user_id = ?"
    ).run(description, amount, type, category, date, req.params.id, req.user.userId);
    res.json({ success: true });
  });

  app.delete("/api/transactions/:id", authenticateToken, (req: any, res) => {
    db.prepare("DELETE FROM transactions WHERE id = ? AND user_id = ?").run(req.params.id, req.user.userId);
    res.json({ success: true });
  });

  // Category Routes
  app.get("/api/categories", authenticateToken, (req: any, res) => {
    const categories = db.prepare("SELECT * FROM categories WHERE user_id = ?").all(req.user.userId);
    res.json(categories);
  });

  app.post("/api/categories", authenticateToken, (req: any, res) => {
    const { name } = req.body;
    try {
      const info = db.prepare("INSERT INTO categories (user_id, name) VALUES (?, ?)").run(req.user.userId, name);
      res.json({ id: info.lastInsertRowid, name });
    } catch (error) {
      res.status(400).json({ error: "Erro ao criar categoria" });
    }
  });

  // Checklist Routes
  app.get("/api/checklist/:month_year", authenticateToken, (req: any, res) => {
    const items = db.prepare("SELECT * FROM checklist_items WHERE user_id = ? AND month_year = ?").all(req.user.userId, req.params.month_year);
    res.json(items);
  });

  app.post("/api/checklist", authenticateToken, (req: any, res) => {
    const { title, amount, month_year } = req.body;
    try {
      const info = db.prepare(
        "INSERT INTO checklist_items (user_id, title, amount, month_year) VALUES (?, ?, ?, ?)"
      ).run(req.user.userId, title, amount || 0, month_year);
      res.json({ id: info.lastInsertRowid, title, amount: amount || 0, is_done: 0, month_year });
    } catch (error) {
      res.status(400).json({ error: "Erro ao criar item da lista" });
    }
  });

  app.put("/api/checklist/:id", authenticateToken, (req: any, res) => {
    const { is_done, title, amount } = req.body;
    
    if (is_done !== undefined) {
      db.prepare(
        "UPDATE checklist_items SET is_done = ? WHERE id = ? AND user_id = ?"
      ).run(is_done ? 1 : 0, req.params.id, req.user.userId);
    }
    
    if (title !== undefined || amount !== undefined) {
      const currentItem: any = db.prepare("SELECT * FROM checklist_items WHERE id = ? AND user_id = ?").get(req.params.id, req.user.userId);
      if (currentItem) {
        const newTitle = title !== undefined ? title : currentItem.title;
        const newAmount = amount !== undefined ? amount : currentItem.amount;
        db.prepare(
          "UPDATE checklist_items SET title = ?, amount = ? WHERE id = ? AND user_id = ?"
        ).run(newTitle, newAmount, req.params.id, req.user.userId);
      }
    }
    
    res.json({ success: true });
  });

  app.delete("/api/checklist/:id", authenticateToken, (req: any, res) => {
    db.prepare("DELETE FROM checklist_items WHERE id = ? AND user_id = ?").run(req.params.id, req.user.userId);
    res.json({ success: true });
  });

  // Profile Routes
  app.put("/api/profile", authenticateToken, (req: any, res) => {
    const { username, theme, fixed_date } = req.body;
    try {
      // Use existing values if not provided
      const currentUser: any = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.userId);
      
      const newUsername = username !== undefined ? username : currentUser.username;
      const newTheme = theme !== undefined ? theme : currentUser.theme;
      const newFixedDate = fixed_date !== undefined ? fixed_date : currentUser.fixed_date;

      console.log(`[PROFILE] Updating user ${req.user.userId}: username=${newUsername}, theme=${newTheme}`);
      db.prepare(
        "UPDATE users SET username = ?, theme = ?, fixed_date = ? WHERE id = ?"
      ).run(newUsername, newTheme, newFixedDate, req.user.userId);
      
      const updatedUser: any = db.prepare("SELECT id, username, email, theme, fixed_date FROM users WHERE id = ?").get(req.user.userId);
      res.json(updatedUser);
    } catch (error) {
      console.error('Profile update error:', error);
      res.status(400).json({ error: "Erro ao atualizar perfil" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
