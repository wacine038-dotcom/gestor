import { useState, useEffect } from 'react';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import { API_BASE_URL } from './constants';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);
  const [serverStatus, setServerStatus] = useState<'checking' | 'ok' | 'error'>('checking');

  useEffect(() => {
    const checkServer = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/health`);
        if (response.ok) {
          setServerStatus('ok');
        } else {
          setServerStatus('error');
        }
      } catch (err) {
        console.error('[APP] Server check failed:', err);
        setServerStatus('error');
      }
    };

    checkServer();

    const savedToken = localStorage.getItem('waplay_token');
    const savedUser = localStorage.getItem('waplay_user');
    if (savedToken && savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setToken(savedToken);
      setUser(parsedUser);
      if (parsedUser.theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
    setChecking(false);
  }, []);

  const handleLogin = (newToken: string, newUser: any) => {
    setToken(newToken);
    setUser(newUser);
    localStorage.setItem('waplay_token', newToken);
    localStorage.setItem('waplay_user', JSON.stringify(newUser));
    if (newUser.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleUpdateUser = (updatedUser: any) => {
    setUser(updatedUser);
    localStorage.setItem('waplay_user', JSON.stringify(updatedUser));
    if (updatedUser.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('waplay_token');
    localStorage.removeItem('waplay_user');
  };

  if (checking) return null;

  return (
    <div className="min-h-screen bg-[#F5F5F0] dark:bg-[#0a0a0a] transition-colors duration-300">
      {serverStatus === 'error' && (
        <div className="fixed top-0 left-0 w-full bg-red-500 text-white text-center py-2 text-sm z-50">
          Não foi possível conectar ao servidor em <span className="font-mono font-bold">{API_BASE_URL || window.location.origin}</span>. Verifique sua conexão.
        </div>
      )}
      {!token ? (
        <Auth onLogin={handleLogin} />
      ) : (
        <Dashboard user={user} token={token} onLogout={handleLogout} onUpdateUser={handleUpdateUser} />
      )}
    </div>
  );
}
