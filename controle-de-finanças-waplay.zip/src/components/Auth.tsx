import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Wallet, Lock, User, ArrowRight, Mail, ArrowLeft } from 'lucide-react';
import { API_BASE_URL } from '../constants';

interface AuthProps {
  onLogin: (token: string, user: any) => void;
}

type AuthView = 'login' | 'register' | 'forgot' | 'reset';

export default function Auth({ onLogin }: AuthProps) {
  const [view, setView] = useState<AuthView>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [resetToken, setResetToken] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    if (window.location.pathname === '/reset-password' && token) {
      setView('reset');
      setResetToken(token);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    let endpoint = '';
    let body: any = {};

    if (view === 'login') {
      endpoint = '/api/login';
      body = { username, password };
    } else if (view === 'register') {
      endpoint = '/api/register';
      body = { username, email, password };
    } else if (view === 'forgot') {
      endpoint = '/api/forgot-password';
      body = { email };
    } else if (view === 'reset') {
      if (password !== confirmPassword) {
        setError('As senhas não coincidem');
        setLoading(false);
        return;
      }
      endpoint = '/api/reset-password';
      body = { token: resetToken, newPassword: password };
    }

    const url = `${API_BASE_URL}${endpoint}`;
    try {
      console.log(`[AUTH] Fetching ${url}`);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const contentType = response.headers.get("content-type");
      let data;
      
      if (contentType && contentType.includes("application/json")) {
        data = await response.json();
      } else {
        const text = await response.text();
        console.error(`[AUTH] Non-JSON response from ${url}:`, text.substring(0, 200));
        throw new Error('O servidor não retornou um JSON válido');
      }

      if (response.ok) {
        if (view === 'login') {
          onLogin(data.token, data.user);
        } else if (view === 'register') {
          setView('login');
          setUsername('');
          setPassword('');
          setEmail('');
          setMessage('Conta criada com sucesso! Por favor, faça login.');
        } else if (view === 'forgot') {
          setMessage(data.message);
          setEmail('');
        } else if (view === 'reset') {
          setView('login');
          setPassword('');
          setConfirmPassword('');
          setMessage('Senha atualizada com sucesso! Por favor, faça login.');
          // Clear URL params
          window.history.replaceState({}, document.title, "/");
        }
      } else {
        setError(data.error || 'Ocorreu um erro');
      }
    } catch (err: any) {
      console.error('[AUTH] Connection error details:', {
        message: err.message,
        url: url,
        stack: err.stack
      });
      
      let errorMessage = 'Erro de conexão com o servidor.';
      
      if (err.message === 'O servidor não retornou um JSON válido') {
        errorMessage = 'Erro interno: O servidor não respondeu no formato esperado.';
      } else if (err.message.includes('Failed to fetch')) {
        errorMessage = `Não foi possível alcançar o servidor em ${url}. Verifique se o backend está rodando e se a URL está correta.`;
      } else {
        errorMessage = `Erro: ${err.message}`;
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getTitle = () => {
    switch (view) {
      case 'login': return 'Bem-vindo de volta!';
      case 'register': return 'Comece sua jornada financeira';
      case 'forgot': return 'Recuperar Conta';
      case 'reset': return 'Nova Senha';
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F0] flex items-center justify-center p-4 font-sans">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-[32px] shadow-xl shadow-black/5 p-8 border border-black/5"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-[#5A5A40] rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-[#5A5A40]/20">
            <Wallet className="text-white w-8 h-8" />
          </div>
          <h1 className="text-2xl font-semibold text-[#1a1a1a] text-center">
            Controle de Finanças Waplay
          </h1>
          <p className="text-[#5A5A40]/60 text-sm mt-2">
            {getTitle()}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {(view === 'login' || view === 'register') && (
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-[#5A5A40]/40 w-5 h-5" />
              <input
                type="text"
                placeholder="Usuário"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-[#F5F5F0] border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-[#5A5A40] transition-all outline-none"
                required
              />
            </div>
          )}

          {(view === 'register' || view === 'forgot') && (
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#5A5A40]/40 w-5 h-5" />
              <input
                type="email"
                placeholder="E-mail"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#F5F5F0] border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-[#5A5A40] transition-all outline-none"
                required
              />
            </div>
          )}

          {(view === 'login' || view === 'register' || view === 'reset') && (
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#5A5A40]/40 w-5 h-5" />
              <input
                type="password"
                placeholder={view === 'reset' ? 'Nova Senha' : 'Senha'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#F5F5F0] border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-[#5A5A40] transition-all outline-none"
                required
              />
            </div>
          )}

          {view === 'reset' && (
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#5A5A40]/40 w-5 h-5" />
              <input
                type="password"
                placeholder="Confirmar Nova Senha"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-[#F5F5F0] border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-[#5A5A40] transition-all outline-none"
                required
              />
            </div>
          )}

          {error && (
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-500 text-sm text-center"
            >
              {error}
            </motion.p>
          )}

          {message && (
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-[#5A5A40] text-sm text-center bg-[#F5F5F0] p-3 rounded-xl"
            >
              {message}
            </motion.p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#5A5A40] text-white rounded-2xl py-4 font-medium flex items-center justify-center gap-2 hover:bg-[#4A4A30] transition-all shadow-lg shadow-[#5A5A40]/20 disabled:opacity-50"
          >
            {loading ? 'Processando...' : 
              view === 'login' ? 'Entrar' : 
              view === 'register' ? 'Criar Conta' : 
              view === 'forgot' ? 'Enviar Link' : 'Redefinir Senha'}
            <ArrowRight className="w-5 h-5" />
          </button>
        </form>

        <div className="mt-8 flex flex-col gap-3 text-center">
          {view === 'login' && (
            <button
              onClick={() => setView('forgot')}
              className="text-[#5A5A40]/60 hover:text-[#5A5A40] text-sm"
            >
              Esqueceu sua senha?
            </button>
          )}

          <button
            onClick={() => {
              if (view === 'login') setView('register');
              else setView('login');
              setError('');
              setMessage('');
            }}
            className="text-[#5A5A40] font-medium hover:underline text-sm flex items-center justify-center gap-1"
          >
            {view === 'login' ? 'Não tem uma conta? Inscreva-se' : 
             view === 'forgot' ? <><ArrowLeft className="w-4 h-4" /> Voltar para o Login</> :
             'Já tem uma conta? Entre'}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
