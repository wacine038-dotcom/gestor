import React from 'react';
import { 
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { format } from 'date-fns';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  Legend
} from 'recharts';

interface ChartsProps {
  pieData: any[];
  annualData: any[];
  user: any;
  currentMonth: Date;
  COLORS: string[];
}

const Charts: React.FC<ChartsProps> = ({ pieData, annualData, user, currentMonth, COLORS }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 overflow-hidden">
      {/* Monthly Expenses Pie Chart */}
      <div className="bg-white dark:bg-[#151515] p-8 rounded-[32px] border border-black/5 dark:border-white/5 shadow-sm transition-colors">
        <div className="flex items-center gap-2 mb-6">
          <PieChartIcon className="w-5 h-5 text-[#5A5A40] dark:text-[#A0A080]" />
          <h3 className="text-lg font-semibold text-[#1a1a1a] dark:text-white">Gastos por Categoria</h3>
        </div>
        <div className="h-[300px] w-full">
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)', 
                    backgroundColor: user.theme === 'dark' ? '#1a1a1a' : '#fff', 
                    color: user.theme === 'dark' ? '#fff' : '#000' 
                  }}
                  itemStyle={{ color: user.theme === 'dark' ? '#fff' : '#000' }}
                  formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
                />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-[#5A5A40]/40 dark:text-[#A0A080]/40">
              <PieChartIcon className="w-12 h-12 mb-2 opacity-20" />
              <p>Sem despesas este mês</p>
            </div>
          )}
        </div>
      </div>

      {/* Annual Income/Expense Bar Chart */}
      <div className="bg-white dark:bg-[#151515] p-8 rounded-[32px] border border-black/5 dark:border-white/5 shadow-sm transition-colors">
        <div className="flex items-center gap-2 mb-6">
          <BarChartIcon className="w-5 h-5 text-[#5A5A40] dark:text-[#A0A080]" />
          <h3 className="text-lg font-semibold text-[#1a1a1a] dark:text-white">Fluxo Anual ({format(currentMonth, 'yyyy')})</h3>
        </div>
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={annualData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={user.theme === 'dark' ? '#333' : '#E5E5E5'} />
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                tick={{ fill: user.theme === 'dark' ? '#A0A080' : '#5A5A40', fontSize: 10 }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fill: user.theme === 'dark' ? '#A0A080' : '#5A5A40', fontSize: 10 }}
                width={40}
              />
              <Tooltip 
                contentStyle={{ 
                  borderRadius: '16px', 
                  border: 'none', 
                  boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)', 
                  backgroundColor: user.theme === 'dark' ? '#1a1a1a' : '#fff', 
                  color: user.theme === 'dark' ? '#fff' : '#000' 
                }}
                itemStyle={{ color: user.theme === 'dark' ? '#fff' : '#000' }}
                formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
              />
              <Legend verticalAlign="bottom" height={36}/>
              <Bar dataKey="receita" fill="#10B981" radius={[4, 4, 0, 0]} name="Receita" />
              <Bar dataKey="despesa" fill="#F43F5E" radius={[4, 4, 0, 0]} name="Despesa" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Charts;
