import React, { useState, useEffect, useMemo, Suspense, lazy } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle2,
  Circle,
  Edit2,
  ListTodo,
  Plus, 
  TrendingUp, 
  TrendingDown, 
  LogOut, 
  Calendar, 
  Tag, 
  Trash2,
  DollarSign,
  PieChart as PieChartIcon,
  BarChart as BarChartIcon,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  LayoutDashboard,
  Settings,
  UserCircle,
  Moon,
  Sun
} from 'lucide-react';
import { format, startOfDay, parseISO, startOfMonth, endOfMonth, isWithinInterval, addMonths, subMonths, startOfYear, endOfYear, eachMonthOfInterval, setMonth, setYear, getYear, getMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { API_BASE_URL } from '../constants';

const Charts = lazy(() => import('./Charts'));

interface Transaction {
  id: number;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  date: string;
}

interface DashboardProps {
  user: any;
  token: string;
  onLogout: () => void;
  onUpdateUser: (user: any) => void;
}

const COLORS = ['#5A5A40', '#F43F5E', '#10B981', '#F59E0B', '#3B82F6', '#8B5CF6', '#EC4899'];

export default function Dashboard({ user, token, onLogout, onUpdateUser }: DashboardProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [category, setCategory] = useState('Geral');
  const [date, setDate] = useState('');
  const [loading, setLoading] = useState(true);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [showCharts, setShowCharts] = useState(true);
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  const [categories, setCategories] = useState<any[]>([]);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);

  // Checklist state
  const [checklistItems, setChecklistItems] = useState<any[]>([]);
  const [newChecklistItem, setNewChecklistItem] = useState('');
  const [newChecklistAmount, setNewChecklistAmount] = useState('');
  const [showChecklist, setShowChecklist] = useState(false);
  const [editingChecklistId, setEditingChecklistId] = useState<number | null>(null);
  const [editChecklistTitle, setEditChecklistTitle] = useState('');
  const [editChecklistAmount, setEditChecklistAmount] = useState('');

  // Profile state
  const [showProfile, setShowProfile] = useState(false);
  const [profileUsername, setProfileUsername] = useState(user.username);
  const [profileTheme, setProfileTheme] = useState(user.theme || 'light');
  const [profileLoading, setProfileLoading] = useState(false);

  // Sync profile state when modal opens
  useEffect(() => {
    if (showProfile) {
      setProfileUsername(user.username);
      setProfileTheme(user.theme || 'light');
    }
  }, [showProfile, user]);

  const fetchTransactions = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/transactions`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setTransactions(data);
    } catch (err) {
      console.error('Error fetching transactions');
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/categories`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setCategories(data);
    } catch (err) {
      console.error('Error fetching categories');
    }
  };

  const fetchChecklist = async () => {
    try {
      const monthYear = format(currentMonth, 'yyyy-MM');
      const response = await fetch(`${API_BASE_URL}/api/checklist/${monthYear}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setChecklistItems(data);
    } catch (err) {
      console.error('Error fetching checklist');
    }
  };

  useEffect(() => {
    fetchTransactions();
    fetchCategories();
    fetchChecklist();
  }, [currentMonth]);

  const filteredTransactions = useMemo(() => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    return transactions.filter(t => {
      const date = parseISO(t.date);
      return isWithinInterval(date, { start, end });
    });
  }, [transactions, currentMonth]);

  const pieData = useMemo(() => {
    const expenses = filteredTransactions.filter(t => t.type === 'expense');
    const categories: { [key: string]: number } = {};
    
    expenses.forEach(t => {
      categories[t.category] = (categories[t.category] || 0) + t.amount;
    });

    return Object.entries(categories).map(([name, value]) => ({
      name,
      value
    }));
  }, [filteredTransactions]);

  const annualData = useMemo(() => {
    const start = startOfYear(currentMonth);
    const end = endOfYear(currentMonth);
    const months = eachMonthOfInterval({ start, end });
    
    return months.map(month => {
      const monthStart = startOfMonth(month);
      const monthEnd = endOfMonth(month);
      
      const monthTransactions = transactions.filter(t => {
        const date = parseISO(t.date);
        return isWithinInterval(date, { start: monthStart, end: monthEnd });
      });

      const income = monthTransactions
        .filter(t => t.type === 'income')
        .reduce((acc, t) => acc + t.amount, 0);
      
      const expense = monthTransactions
        .filter(t => t.type === 'expense')
        .reduce((acc, t) => acc + t.amount, 0);

      return {
        name: format(month, 'MMM', { locale: ptBR }),
        receita: income,
        despesa: expense
      };
    });
  }, [transactions, currentMonth]);

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    
    let finalCategory = category;
    if (category === 'NEW_CATEGORY' && newCategoryName.trim()) {
      try {
        const catRes = await fetch(`${API_BASE_URL}/api/categories`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ name: newCategoryName.trim() }),
        });
        const newCat = await catRes.json();
        finalCategory = newCat.name;
        fetchCategories();
      } catch (err) {
        console.error('Error creating category');
      }
    }

    const transactionData = {
      description,
      amount: parseFloat(amount),
      type,
      category: finalCategory,
      date: date || new Date().toISOString()
    };

    try {
      const url = editingId ? `${API_BASE_URL}/api/transactions/${editingId}` : `${API_BASE_URL}/api/transactions`;
      const method = editingId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(transactionData),
      });

      if (response.ok) {
        fetchTransactions();
        setShowForm(false);
        setEditingId(null);
        setDescription('');
        setAmount('');
        setNewCategoryName('');
        setIsCreatingCategory(false);
      }
    } catch (err) {
      console.error('Error saving transaction');
    }
  };

  const handleEdit = (t: Transaction) => {
    setEditingId(t.id);
    setDescription(t.description);
    setAmount(t.amount.toString());
    setType(t.type);
    setCategory(t.category);
    setDate(format(parseISO(t.date), 'yyyy-MM-dd'));
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    try {
      await fetch(`${API_BASE_URL}/api/transactions/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchTransactions();
    } catch (err) {
      console.error('Error deleting transaction');
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/profile`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ 
          username: profileUsername, 
          theme: profileTheme || 'light'
        }),
      });

      if (response.ok) {
        const updatedUser = await response.json();
        onUpdateUser(updatedUser);
        setShowProfile(false);
      }
    } catch (err) {
      console.error('Error updating profile');
    } finally {
      setProfileLoading(false);
    }
  };

  const totalIncome = filteredTransactions
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + t.amount, 0);

  const totalExpense = filteredTransactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + t.amount, 0);

  const balance = totalIncome - totalExpense;

  const previousBalance = useMemo(() => {
    const startOfPrev = startOfMonth(subMonths(currentMonth, 1));
    const endOfPrev = endOfMonth(subMonths(currentMonth, 1));
    const prevTransactions = transactions.filter(t => {
      const date = parseISO(t.date);
      return isWithinInterval(date, { start: startOfPrev, end: endOfPrev });
    });
    const income = prevTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
    const expense = prevTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
    return income - expense;
  }, [transactions, currentMonth]);

  const accumulatedBalance = useMemo(() => {
    const endOfCurrent = endOfMonth(currentMonth);
    const pastTransactions = transactions.filter(t => {
      const date = parseISO(t.date);
      return date <= endOfCurrent;
    });
    const income = pastTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
    const expense = pastTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
    return income - expense;
  }, [transactions, currentMonth]);

  const handleAddChecklistItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChecklistItem.trim()) return;

    try {
      const monthYear = format(currentMonth, 'yyyy-MM');
      const response = await fetch(`${API_BASE_URL}/api/checklist`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ 
          title: newChecklistItem, 
          amount: parseFloat(newChecklistAmount) || 0,
          month_year: monthYear 
        }),
      });
      if (response.ok) {
        const newItem = await response.json();
        setChecklistItems([...checklistItems, newItem]);
        setNewChecklistItem('');
        setNewChecklistAmount('');
      }
    } catch (err) {
      console.error('Error adding checklist item');
    }
  };

  const handleToggleChecklistItem = async (id: number, isDone: boolean) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/checklist/${id}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ is_done: !isDone }),
      });
      if (response.ok) {
        setChecklistItems(checklistItems.map(item => 
          item.id === id ? { ...item, is_done: !isDone ? 1 : 0 } : item
        ));
      }
    } catch (err) {
      console.error('Error toggling checklist item');
    }
  };

  const handleUpdateChecklistItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingChecklistId || !editChecklistTitle.trim()) return;

    try {
      const response = await fetch(`${API_BASE_URL}/api/checklist/${editingChecklistId}`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ 
          title: editChecklistTitle, 
          amount: parseFloat(editChecklistAmount) || 0 
        }),
      });
      if (response.ok) {
        setChecklistItems(checklistItems.map(item => 
          item.id === editingChecklistId 
            ? { ...item, title: editChecklistTitle, amount: parseFloat(editChecklistAmount) || 0 } 
            : item
        ));
        setEditingChecklistId(null);
      }
    } catch (err) {
      console.error('Error updating checklist item');
    }
  };

  const handleDeleteChecklistItem = async (id: number) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/checklist/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        setChecklistItems(checklistItems.filter(item => item.id !== id));
      }
    } catch (err) {
      console.error('Error deleting checklist item');
    }
  };

  const handleImportPreviousChecklist = async () => {
    const prevMonthYear = format(subMonths(currentMonth, 1), 'yyyy-MM');
    const currentMonthYear = format(currentMonth, 'yyyy-MM');
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/checklist/${prevMonthYear}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const prevItems = await response.json();
      
      if (prevItems.length === 0) {
        alert('Nenhuma tarefa encontrada no mês anterior.');
        return;
      }

      // Add each item to the current month
      for (const item of prevItems) {
        await fetch(`${API_BASE_URL}/api/checklist`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ 
            title: item.title, 
            amount: item.amount,
            month_year: currentMonthYear 
          }),
        });
      }
      fetchChecklist();
    } catch (err) {
      console.error('Error importing checklist');
    }
  };

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

  const handleMonthChange = (month: number) => {
    setCurrentMonth(setMonth(currentMonth, month));
  };

  const handleYearChange = (year: number) => {
    setCurrentMonth(setYear(currentMonth, year));
  };

  const years = useMemo(() => {
    const currentYear = getYear(new Date());
    const yearsArray = [];
    for (let i = currentYear - 5; i <= currentYear + 5; i++) {
      yearsArray.push(i);
    }
    return yearsArray;
  }, []);

  const months = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  return (
    <div className="min-h-screen bg-[#F5F5F0] dark:bg-[#0a0a0a] font-sans pb-20 transition-colors duration-300">
      {/* Header */}
      <header className="bg-white dark:bg-[#151515] border-b border-black/5 dark:border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-10 transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#5A5A40] rounded-xl flex items-center justify-center">
            <DollarSign className="text-white w-6 h-6" />
          </div>
          <h1 className="font-semibold text-[#1a1a1a] dark:text-white">Controle de Finanças Waplay</h1>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowProfile(true)}
            className="p-2 hover:bg-[#F5F5F0] dark:hover:bg-white/5 text-[#5A5A40] dark:text-[#A0A080] rounded-lg transition-colors flex items-center gap-2"
            title="Perfil e Configurações"
          >
            <span className="text-sm hidden sm:block">Olá, {user.username}</span>
            <UserCircle className="w-6 h-6" />
          </button>
          <button 
            onClick={onLogout}
            className="p-2 hover:bg-red-50 dark:hover:bg-red-500/10 text-red-500 rounded-lg transition-colors"
            title="Sair"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-6 space-y-8">
        {/* Month Selector */}
        <div className="flex flex-col sm:flex-row items-center justify-between bg-white dark:bg-[#151515] p-4 rounded-[24px] border border-black/5 dark:border-white/5 shadow-sm transition-colors gap-4">
          <div className="flex items-center gap-2">
            <button onClick={prevMonth} className="p-2 hover:bg-[#F5F5F0] dark:hover:bg-white/5 rounded-xl transition-colors">
              <ChevronLeft className="w-5 h-5 text-[#5A5A40] dark:text-[#A0A080]" />
            </button>
            <div className="text-center min-w-[140px]">
              <h2 className="text-lg font-bold text-[#1a1a1a] dark:text-white capitalize">
                {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
              </h2>
              <p className="text-xs text-[#5A5A40]/60 dark:text-[#A0A080]/60">Período Selecionado</p>
            </div>
            <button onClick={nextMonth} className="p-2 hover:bg-[#F5F5F0] dark:hover:bg-white/5 rounded-xl transition-colors">
              <ChevronRight className="w-5 h-5 text-[#5A5A40] dark:text-[#A0A080]" />
            </button>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select 
              value={getMonth(currentMonth)}
              onChange={(e) => handleMonthChange(parseInt(e.target.value))}
              className="flex-1 sm:flex-none bg-[#F5F5F0] dark:bg-white/5 border-none rounded-xl py-2 px-3 text-sm font-medium text-[#5A5A40] dark:text-[#A0A080] outline-none focus:ring-2 focus:ring-[#5A5A40] transition-all"
            >
              {months.map((month, index) => (
                <option key={month} value={index}>{month}</option>
              ))}
            </select>
            <select 
              value={getYear(currentMonth)}
              onChange={(e) => handleYearChange(parseInt(e.target.value))}
              className="flex-1 sm:flex-none bg-[#F5F5F0] dark:bg-white/5 border-none rounded-xl py-2 px-3 text-sm font-medium text-[#5A5A40] dark:text-[#A0A080] outline-none focus:ring-2 focus:ring-[#5A5A40] transition-all"
            >
              {years.map(year => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-[#151515] p-6 rounded-[32px] border border-black/5 dark:border-white/5 shadow-sm transition-colors"
          >
            <p className="text-sm text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-2">Saldo Mensal</p>
            <h2 className={`text-3xl font-bold ${balance >= 0 ? 'text-[#1a1a1a] dark:text-white' : 'text-rose-500'}`}>
              R$ {balance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </h2>
            <p className="text-[10px] mt-1 text-[#5A5A40]/40 dark:text-[#A0A080]/40">
              Anterior: R$ {previousBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="bg-white dark:bg-[#151515] p-6 rounded-[32px] border border-black/5 dark:border-white/5 shadow-sm transition-colors"
          >
            <p className="text-sm text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-2">Saldo Acumulado</p>
            <h2 className={`text-3xl font-bold ${accumulatedBalance >= 0 ? 'text-[#1a1a1a] dark:text-white' : 'text-rose-500'}`}>
              R$ {accumulatedBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </h2>
            <p className="text-[10px] mt-1 text-[#5A5A40]/40 dark:text-[#A0A080]/40">
              Até {format(endOfMonth(currentMonth), 'dd/MM/yyyy')}
            </p>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-emerald-50 dark:bg-emerald-500/10 p-6 rounded-[32px] border border-emerald-100 dark:border-emerald-500/20 transition-colors"
          >
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-500 mb-2">
              <TrendingUp className="w-4 h-4" />
              <p className="text-sm font-medium">Receitas</p>
            </div>
            <h2 className="text-2xl font-bold text-emerald-700 dark:text-emerald-400">
              R$ {totalIncome.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </h2>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-rose-50 dark:bg-rose-500/10 p-6 rounded-[32px] border border-rose-100 dark:border-rose-500/20 transition-colors"
          >
            <div className="flex items-center gap-2 text-rose-600 dark:text-rose-500 mb-2">
              <TrendingDown className="w-4 h-4" />
              <p className="text-sm font-medium">Despesas</p>
            </div>
            <h2 className="text-2xl font-bold text-rose-700 dark:text-rose-400">
              R$ {totalExpense.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </h2>
          </motion.div>
        </div>

        {/* Checklist Section */}
        <div className="bg-white dark:bg-[#151515] p-8 rounded-[32px] border border-black/5 dark:border-white/5 shadow-sm transition-colors">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-[#5A5A40]/10 rounded-xl">
                <ListTodo className="w-5 h-5 text-[#5A5A40] dark:text-[#A0A080]" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-[#1a1a1a] dark:text-white">Lista de Controle</h3>
                <p className="text-xs text-[#5A5A40]/60 dark:text-[#A0A080]/60">Tarefas para {format(currentMonth, 'MMMM', { locale: ptBR })}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={handleImportPreviousChecklist}
                className="text-xs font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 hover:text-[#5A5A40] dark:hover:text-[#A0A080] transition-colors"
                title="Importar do mês anterior"
              >
                Importar Anterior
              </button>
              <button 
                onClick={() => setShowChecklist(!showChecklist)}
                className="text-sm font-medium text-[#5A5A40] dark:text-[#A0A080] hover:underline"
              >
                {showChecklist ? 'Recolher' : 'Expandir'}
              </button>
            </div>
          </div>

          <AnimatePresence>
            {showChecklist && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <form onSubmit={handleAddChecklistItem} className="flex flex-col sm:flex-row gap-2 mb-6">
                  <input 
                    type="text"
                    value={newChecklistItem}
                    onChange={(e) => setNewChecklistItem(e.target.value)}
                    placeholder="Nova tarefa..."
                    className="flex-1 bg-[#F5F5F0] dark:bg-white/5 border-none rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-all"
                  />
                  <div className="flex gap-2">
                    <input 
                      type="number"
                      step="0.01"
                      value={newChecklistAmount}
                      onChange={(e) => setNewChecklistAmount(e.target.value)}
                      placeholder="Valor (opcional)"
                      className="w-32 bg-[#F5F5F0] dark:bg-white/5 border-none rounded-xl py-3 px-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-all"
                    />
                    <button 
                      type="submit"
                      className="p-3 bg-[#5A5A40] text-white rounded-xl hover:bg-[#4A4A30] transition-all shadow-lg shadow-[#5A5A40]/20"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                </form>

                <div className="space-y-3">
                  {checklistItems.length > 0 ? (
                    checklistItems.map((item) => (
                      <motion.div 
                        key={item.id}
                        layout
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="p-4 bg-[#F5F5F0]/50 dark:bg-white/5 rounded-2xl group transition-colors"
                      >
                        {editingChecklistId === item.id ? (
                          <form onSubmit={handleUpdateChecklistItem} className="flex flex-col sm:flex-row gap-2">
                            <input 
                              type="text"
                              value={editChecklistTitle}
                              onChange={(e) => setEditChecklistTitle(e.target.value)}
                              className="flex-1 bg-white dark:bg-white/10 border-none rounded-xl py-2 px-3 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-all text-sm"
                              autoFocus
                            />
                            <div className="flex gap-2">
                              <input 
                                type="number"
                                step="0.01"
                                value={editChecklistAmount}
                                onChange={(e) => setEditChecklistAmount(e.target.value)}
                                className="w-24 bg-white dark:bg-white/10 border-none rounded-xl py-2 px-3 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-all text-sm"
                              />
                              <button 
                                type="submit"
                                className="px-4 py-2 bg-[#5A5A40] text-white rounded-xl hover:bg-[#4A4A30] transition-all text-sm font-medium"
                              >
                                Salvar
                              </button>
                              <button 
                                type="button"
                                onClick={() => setEditingChecklistId(null)}
                                className="px-4 py-2 bg-gray-200 dark:bg-white/10 text-gray-700 dark:text-gray-300 rounded-xl hover:bg-gray-300 dark:hover:bg-white/20 transition-all text-sm font-medium"
                              >
                                Sair
                              </button>
                            </div>
                          </form>
                        ) : (
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3 flex-1">
                              <button 
                                onClick={() => handleToggleChecklistItem(item.id, !!item.is_done)}
                                className={`transition-colors flex-shrink-0 ${item.is_done ? 'text-emerald-500' : 'text-[#5A5A40]/40 dark:text-[#A0A080]/40'}`}
                              >
                                {item.is_done ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
                              </button>
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between flex-1 gap-1">
                                <span className={`text-sm font-medium transition-all ${item.is_done ? 'line-through text-[#5A5A40]/40 dark:text-[#A0A080]/40' : 'text-[#1a1a1a] dark:text-white'}`}>
                                  {item.title}
                                </span>
                                {item.amount > 0 && (
                                  <span className={`text-xs font-bold px-2 py-1 rounded-lg ${item.is_done ? 'bg-gray-100 dark:bg-white/5 text-gray-400' : 'bg-[#5A5A40]/10 text-[#5A5A40] dark:text-[#A0A080]'}`}>
                                    R$ {item.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-1 ml-2">
                              <button 
                                onClick={() => {
                                  setEditingChecklistId(item.id);
                                  setEditChecklistTitle(item.title);
                                  setEditChecklistAmount(item.amount.toString());
                                }}
                                className="opacity-0 group-hover:opacity-100 p-2 text-[#5A5A40] dark:text-[#A0A080] hover:bg-[#5A5A40]/10 rounded-lg transition-all"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={() => handleDeleteChecklistItem(item.id)}
                                className="opacity-0 group-hover:opacity-100 p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-all"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        )}
                      </motion.div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-[#5A5A40]/40 dark:text-[#A0A080]/40">
                      <ListTodo className="w-12 h-12 mx-auto mb-2 opacity-20" />
                      <p>Nenhuma tarefa para este mês</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Charts Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <LayoutDashboard className="w-5 h-5 text-[#5A5A40]" />
              <h3 className="text-lg font-semibold text-[#1a1a1a]">Visão Analítica</h3>
            </div>
            <button 
              onClick={() => setShowCharts(!showCharts)}
              className="flex items-center gap-2 text-sm font-medium text-[#5A5A40] bg-white px-4 py-2 rounded-full border border-black/5 hover:bg-[#F5F5F0] transition-all"
            >
              {showCharts ? (
                <>
                  <ChevronUp className="w-4 h-4" />
                  Minimizar Gráficos
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4" />
                  Mostrar Gráficos
                </>
              )}
            </button>
          </div>

          <AnimatePresence>
            {showCharts && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <Suspense fallback={
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white dark:bg-[#151515] p-8 rounded-[32px] border border-black/5 dark:border-white/5 shadow-sm h-[400px] animate-pulse flex items-center justify-center">
                      <div className="text-[#5A5A40]/40">Carregando Gráficos...</div>
                    </div>
                    <div className="bg-white dark:bg-[#151515] p-8 rounded-[32px] border border-black/5 dark:border-white/5 shadow-sm h-[400px] animate-pulse flex items-center justify-center">
                      <div className="text-[#5A5A40]/40">Carregando Gráficos...</div>
                    </div>
                  </div>
                }>
                  <Charts 
                    pieData={pieData} 
                    annualData={annualData} 
                    user={user} 
                    currentMonth={currentMonth} 
                    COLORS={COLORS} 
                  />
                </Suspense>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Transactions Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-semibold text-[#1a1a1a] dark:text-white">Transações de {format(currentMonth, 'MMMM', { locale: ptBR })}</h3>
            <button 
              onClick={() => {
                setEditingId(null);
                setDescription('');
                setAmount('');
                setCategory('Geral');
                setNewCategoryName('');
                setIsCreatingCategory(false);
                // Default to current day if in current month, otherwise 1st of selected month
                const today = new Date();
                if (getMonth(today) === getMonth(currentMonth) && getYear(today) === getYear(currentMonth)) {
                  setDate(format(today, 'yyyy-MM-dd'));
                } else {
                  setDate(format(startOfMonth(currentMonth), 'yyyy-MM-dd'));
                }
                setShowForm(true);
              }}
              className="bg-[#5A5A40] text-white px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 hover:bg-[#4A4A30] transition-all shadow-lg shadow-[#5A5A40]/20"
            >
              <Plus className="w-4 h-4" />
              Nova Transação
            </button>
          </div>

          <div className="space-y-3">
            {loading ? (
              <div className="text-center py-10 text-[#5A5A40]/40 dark:text-[#A0A080]/40">Carregando...</div>
            ) : filteredTransactions.length === 0 ? (
              <div className="bg-white dark:bg-[#151515] p-10 rounded-[32px] border border-dashed border-[#5A5A40]/20 dark:border-white/10 text-center transition-colors">
                <PieChartIcon className="w-12 h-12 text-[#5A5A40]/20 dark:text-[#A0A080]/20 mx-auto mb-4" />
                <p className="text-[#5A5A40]/60 dark:text-[#A0A080]/60">Nenhuma transação neste mês.</p>
              </div>
            ) : (
              filteredTransactions.map((t) => (
                <motion.div 
                  key={t.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-white dark:bg-[#151515] p-4 rounded-2xl border border-black/5 dark:border-white/5 flex items-center justify-between hover:shadow-md transition-all group"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                      t.type === 'income' ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-500' : 'bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-500'
                    }`}>
                      {t.type === 'income' ? <TrendingUp className="w-6 h-6" /> : <TrendingDown className="w-6 h-6" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-[#1a1a1a] dark:text-white truncate">{t.description}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-xs text-[#5A5A40]/60 dark:text-[#A0A080]/60 flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {format(new Date(t.date), 'dd MMM yyyy', { locale: ptBR })}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Category Column */}
                  <div className="hidden md:flex items-center justify-center px-4 w-32 shrink-0">
                    <span className="text-xs font-medium bg-[#F5F5F0] dark:bg-white/5 text-[#5A5A40] dark:text-[#A0A080] px-3 py-1 rounded-full border border-black/5 dark:border-white/5 flex items-center gap-1">
                      <Tag className="w-3 h-3" /> {t.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    <p className={`font-bold whitespace-nowrap ${t.type === 'income' ? 'text-emerald-600 dark:text-emerald-500' : 'text-rose-600 dark:text-rose-500'}`}>
                      {t.type === 'income' ? '+' : '-'} R$ {t.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                    <div className="flex items-center gap-1 sm:opacity-0 sm:group-hover:opacity-100 transition-all">
                      <button 
                        onClick={() => handleEdit(t)}
                        className="p-2 text-[#5A5A40]/60 dark:text-[#A0A080]/60 hover:text-[#5A5A40] dark:hover:text-white hover:bg-[#F5F5F0] dark:hover:bg-white/5 rounded-lg transition-all"
                        title="Editar"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setDeleteConfirmId(t.id)}
                        className="p-2 text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-500/10 rounded-lg transition-all"
                        title="Excluir"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </main>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmId && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white dark:bg-[#151515] w-full max-w-sm rounded-[32px] p-8 shadow-2xl text-center transition-colors"
            >
              <div className="w-16 h-16 bg-rose-100 dark:bg-rose-500/20 text-rose-600 dark:text-rose-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-[#1a1a1a] dark:text-white mb-2">Excluir Transação?</h3>
              <p className="text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-6 transition-colors">
                Esta ação não pode ser desfeita. Tem certeza que deseja remover esta transação?
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 py-3 text-[#5A5A40] dark:text-[#A0A080] font-medium hover:bg-[#F5F5F0] dark:hover:bg-white/5 rounded-2xl transition-all"
                >
                  Cancelar
                </button>
                <button 
                  onClick={() => {
                    handleDelete(deleteConfirmId);
                    setDeleteConfirmId(null);
                  }}
                  className="flex-1 py-3 bg-rose-500 text-white font-medium rounded-2xl hover:bg-rose-600 transition-all shadow-lg shadow-rose-500/20"
                >
                  Excluir
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal Form */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white dark:bg-[#151515] w-full max-w-md rounded-[32px] p-8 shadow-2xl transition-colors"
          >
            <h3 className="text-2xl font-bold text-[#1a1a1a] dark:text-white mb-6">
              {editingId ? 'Editar Transação' : 'Nova Transação'}
            </h3>
            <form onSubmit={handleAddTransaction} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-1">Descrição</label>
                <input 
                  type="text" 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-[#F5F5F0] dark:bg-white/5 border-none rounded-2xl py-4 px-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-colors"
                  placeholder="Ex: Supermercado"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-1">Valor (R$)</label>
                <input 
                  type="number" 
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-[#F5F5F0] dark:bg-white/5 border-none rounded-2xl py-4 px-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-colors"
                  placeholder="0,00"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <button 
                  type="button"
                  onClick={() => setType('income')}
                  className={`py-4 rounded-2xl font-medium transition-all ${
                    type === 'income' ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20' : 'bg-[#F5F5F0] dark:bg-white/5 text-[#5A5A40]/60 dark:text-[#A0A080]/60'
                  }`}
                >
                  Receita
                </button>
                <button 
                  type="button"
                  onClick={() => setType('expense')}
                  className={`py-4 rounded-2xl font-medium transition-all ${
                    type === 'expense' ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/20' : 'bg-[#F5F5F0] dark:bg-white/5 text-[#5A5A40]/60 dark:text-[#A0A080]/60'
                  }`}
                >
                  Despesa
                </button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-1">Data</label>
                  <input 
                    type="date" 
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#F5F5F0] dark:bg-white/5 border-none rounded-2xl py-4 px-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-1">Categoria</label>
                  <select 
                    value={category}
                    onChange={(e) => {
                      setCategory(e.target.value);
                      setIsCreatingCategory(e.target.value === 'NEW_CATEGORY');
                    }}
                    className="w-full bg-[#F5F5F0] dark:bg-white/5 border-none rounded-2xl py-4 px-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-colors"
                  >
                    <option value="Geral">Geral</option>
                    <option value="Alimentação">Alimentação</option>
                    <option value="Transporte">Transporte</option>
                    <option value="Lazer">Lazer</option>
                    <option value="Saúde">Saúde</option>
                    <option value="Educação">Educação</option>
                    <option value="Moradia">Moradia</option>
                    <option value="Outro">Outro</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.name}>{cat.name}</option>
                    ))}
                    <option value="NEW_CATEGORY" className="font-bold text-[#5A5A40]">+ Criar Categoria</option>
                  </select>
                </div>
              </div>

              {isCreatingCategory && (
                <motion.div 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <label className="block text-sm font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-1">Nome da Nova Categoria</label>
                  <input 
                    type="text" 
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    className="w-full bg-[#F5F5F0] dark:bg-white/5 border-none rounded-2xl py-4 px-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-colors"
                    placeholder="Ex: Investimentos"
                    required
                  />
                </motion.div>
              )}
              <div className="flex gap-3 pt-4">
                <button 
                  type="button"
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                    setNewCategoryName('');
                    setIsCreatingCategory(false);
                  }}
                  className="flex-1 py-4 text-[#5A5A40] dark:text-[#A0A080] font-medium hover:bg-[#F5F5F0] dark:hover:bg-white/5 rounded-2xl transition-all"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-4 bg-[#5A5A40] text-white font-medium rounded-2xl hover:bg-[#4A4A30] transition-all shadow-lg shadow-[#5A5A40]/20"
                >
                  {editingId ? 'Salvar Alterações' : 'Salvar'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
      {/* Profile Modal */}
      <AnimatePresence>
        {showProfile && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white dark:bg-[#151515] w-full max-w-md rounded-[32px] p-8 shadow-2xl transition-colors"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-[#1a1a1a] dark:text-white">Perfil e Configurações</h2>
                <button onClick={() => {
                  // Revert theme if not saved
                  if (user.theme === 'dark') {
                    document.documentElement.classList.add('dark');
                  } else {
                    document.documentElement.classList.remove('dark');
                  }
                  setShowProfile(false);
                }} className="p-2 hover:bg-[#F5F5F0] dark:hover:bg-white/5 rounded-lg transition-colors">
                  <Plus className="w-6 h-6 rotate-45 text-[#5A5A40] dark:text-[#A0A080]" />
                </button>
              </div>
              
              <form onSubmit={handleUpdateProfile} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-1">Nome de Usuário</label>
                  <div className="relative">
                    <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 text-[#5A5A40]/40 w-5 h-5" />
                    <input 
                      type="text" 
                      value={profileUsername}
                      onChange={(e) => setProfileUsername(e.target.value)}
                      className="w-full bg-[#F5F5F0] dark:bg-white/5 border-none rounded-2xl py-4 pl-12 pr-4 outline-none focus:ring-2 focus:ring-[#5A5A40] dark:text-white transition-colors"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#5A5A40]/60 dark:text-[#A0A080]/60 mb-3">Tema</label>
                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      type="button"
                      onClick={() => {
                        setProfileTheme('light');
                        document.documentElement.classList.remove('dark');
                      }}
                      className={`py-4 rounded-2xl font-medium transition-all flex items-center justify-center gap-2 ${
                        profileTheme === 'light' ? 'bg-[#5A5A40] text-white shadow-lg shadow-[#5A5A40]/20' : 'bg-[#F5F5F0] dark:bg-white/5 text-[#5A5A40]/60 dark:text-[#A0A080]/60'
                      }`}
                    >
                      <Sun className="w-5 h-5" /> Claro
                    </button>
                    <button 
                      type="button"
                      onClick={() => {
                        setProfileTheme('dark');
                        document.documentElement.classList.add('dark');
                      }}
                      className={`py-4 rounded-2xl font-medium transition-all flex items-center justify-center gap-2 ${
                        profileTheme === 'dark' ? 'bg-[#5A5A40] text-white shadow-lg shadow-[#5A5A40]/20' : 'bg-[#F5F5F0] dark:bg-white/5 text-[#5A5A40]/60 dark:text-[#A0A080]/60'
                      }`}
                    >
                      <Moon className="w-5 h-5" /> Escuro
                    </button>
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={profileLoading}
                  className="w-full py-4 bg-[#5A5A40] text-white font-medium rounded-2xl hover:bg-[#4A4A30] transition-all shadow-lg shadow-[#5A5A40]/20 disabled:opacity-50"
                >
                  {profileLoading ? 'Salvando...' : 'Salvar Alterações'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
