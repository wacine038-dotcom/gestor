const rawUrl = import.meta.env.VITE_API_URL || '';
// Remove trailing slash if present to avoid double slashes in URLs
export const API_BASE_URL = rawUrl.endsWith('/') ? rawUrl.slice(0, -1) : rawUrl;
